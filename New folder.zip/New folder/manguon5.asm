# Ma nguon 5 � phan bac dien nang
.data
prompt: .asciiz �Nhap dien nang (kWh): �
msg:    .asciiz �Bac: �
nl:     .asciiz �\n�
 
.text
.globl main
main:
  li  $v0, 4
  la  $a0, prompt
  syscall
  li  $v0, 5            # doc kWh, ket qua o $v0
  syscall
  add $s0, $v0, $zero   # $s0 = dien nang (kWh)
  
  # >>> xac dinh bac (1..4) theo Bang 6, dat vao $s1
  ble $s0, 100, bac_1    # N?u kWh <= 100 -> B?c 1
  ble $s0, 150, bac_2    # N?u kWh <= 150 (v� > 100) -> B?c 2
  ble $s0, 200, bac_3    # N?u kWh <= 200 (v� > 150) -> B?c 3
  li  $s1, 4             # Ng??c l?i (> 200) -> B?c 4
  j   in_ket_qua
   
  bac_1:
   li  $s1, 1
   j   in_ket_qua
  bac_2:
   li  $s1, 2
   j   in_ket_qua
  bac_3:
   li  $s1, 3
  # >>> in �Bac: �, roi $s1, roi xuong dong
  in_ket_qua:
  # >>> in �Bac: �
  li  $v0, 4
  la  $a0, msg
  syscall

  # >>> in gia tri $s1 (so bac)
  li  $v0, 1
  move $a0, $s1
  syscall

  # >>> in xuong dong
  li  $v0, 4
  la  $a0, nl
  syscall
  
  li  $v0, 10
  syscall